import App from './App.svelte';

const app = new App({
	target: document.getElementById('app')
});

export default app;


// TODO: Warn when hint not possible
// TODO: Undo/Redo
// TODO: Import sudoku
// TODO: Creator mode
// TODO: Bug hunt
// TODO: Announce