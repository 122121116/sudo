# [sudoku](https://sudoku.jonasgeiler.com)

This is a very simple sudoku game built with Svelte and TailwindCSS.

Have fun! 😉

已完成内容:
redo,undo
体验优化,分享界面弹窗只会进行一次,不会反复弹窗

> Unfortunately not all features are done yet. Specifically:
> - 创建自己的数独,dropdown文件需要在game.js定义game.startCreatorMode();
> - 提示功能,集成算法进行提示
> - 资源导入,解析网页的html文件,将矩阵导入到项目
> 
